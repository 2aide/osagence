<!-- Le type d'encodage des données, enctype, DOIT être spécifié comme ce qui suit -->
<?php
	if ( $_GET['fic'] == "" )
		{
			header('Location: http://www.agence-libre.fr');
			exit ();
		}
	else
		{
			$fic= $_GET['fic'];
			echo "Le fichier &agrave; envoyer se trouve dans le r&eacute;pertoire: ".$fic;
			$nom = end (explode ( "/" , $_GET['fic'] ));
		}
 ?>
<form enctype="multipart/form-data" action="envoi.php?fic=<?php echo urlencode ($_GET['fic']); ?>" method="post">
  <!-- MAX_FILE_SIZE doit précéder le champ input de type file -->
  <input type="hidden" name="MAX_FILE_SIZE" value="100000000" />
  <!-- Le nom de l'élément input détermine le nom dans le tableau $_FILES -->
  Envoyez ce fichier : <input name="userfile" type="file" />
  <input type="submit" value="Envoyer le fichier" />
</form>
<?php
	if ( $_FILES['userfile']['type'] == "application/x-gzip" )
		{
			if ( $_FILES['userfile']['name'] == $nom )
				{
					$uploads_dir = "/home/unchezvo/www/envoi/upload/";
					if ( move_uploaded_file ( $_FILES['userfile']['tmp_name'] , $uploads_dir.$_FILES['userfile']['name']) )
						{
							echo "Le fichier ".$_FILES['userfile']['name']." &agrave; bien &eacute;t&eacute; envoy&eacute";
						}
					else
						{
							echo "Le fichier ".$_FILES['userfile']['name']." n'a pas &eacute;t&eacute; envoy&eacute";
						}
				}
			else
				{
					echo "<a href=\"envoi.php?fic=".urlencode ($_GET['fic'])."\">Vous avez tent&eacute; d'envoyer un fichier ne correspondant pas &agrave; celui fournis par OSagence, veuillez cliquer ici pour recommencer.</a>";
				}
		}
	else
		{
			if ( $_FILES['userfile']['name'] != "" )
				{
					echo "Le fichier envoy&eacute; n'est pas du type attendu";
				}
		}
?>
