<?php include('protege/entete.inc.php'); ?>
<?php
if (isset($_GET['pr']))
			{
				$pr = $_GET['pr'];
			}
			else {$pr = 0;}
?>
<?php $file = 'index.php'; ?>
<!-- ÿ caractere pour reconnaissance utf8 -->
<meta name="identifier.url" content="http://www.2aide.fr">
<title>Agence immobilière</title>
<meta name="Keywords" content="immobilier...">
<meta name="Description" content="Agence immobili&egrave;re">
<script type="text/javascript" src="pop.js"></script>
</head>
<body>
<div id="corps">
<div id="left">
<div id="menuleft">
<?php include('protege/menutop.inc.php'); ?>
</div>
</div>

<div id="centre">
<div style="position : relative; top : 240px; text-align : center;">

<?php
if ($handle = opendir('fiches/')) {
    while (false !== ($file = readdir($handle))) {
        if ($file != "." && $file != ".." && $file != "lib" && $file != "affiches") {
			$fich = 'fiches/'.$file.'/'.$file.'.php';
			$prix1 = file_get_contents($fich, NULL, NULL, 16, 500);
			$prix2 = strstr ($prix1, 'Prix:');
			$prix = str_replace("Prix: ", "", (substr($prix2, 0, strpos($prix2, '&euro;')+0)));

			if ( $pr == 1 && $prix <= 50000)
			{
			include('fiches/'.$file.'/'.$file.'.php');
			}

			if ( $pr == 2 && $prix > 50000 && $prix <= 100000)
			{
			include('fiches/'.$file.'/'.$file.'.php');
			}

			if ( $pr == 3  && $prix > 100000 && $prix <= 250000)
			{
			include('fiches/'.$file.'/'.$file.'.php');
			}

			if ( $pr == 4  && $prix > 250000 && $prix <= 300000)
			{
			include('fiches/'.$file.'/'.$file.'.php');
			}

			if ( $pr == 5  && $prix > 300000)
			{
			include('fiches/'.$file.'/'.$file.'.php');
			}

			if ( $pr == 0  || $pr > 5 )
			{
			include('fiches/'.$file.'/'.$file.'.php');
			}
        }
    }
    closedir($handle);
}
?>
<a href="http://www.2aide.fr/" title="2aide informatique">Site&nbsp;g&eacute;n&eacute;r&eacute;&nbsp;automatiquement&nbsp;gr&acirc;ce&nbsp;&agrave;&nbsp;une&nbsp;application&nbsp;cr&eacute;e&nbsp;par&nbsp;</a>&nbsp;<a href="http://www.2aide.fr/" title="2aide Informatique"><img style="background-color : inherit; text-decoration : none; border : none;" alt="Logo 2aide" align="middle" src="http://www.2aide.fr/images/2z.gif"></a>
</div>
</div>
</div>
</body>
</html>
