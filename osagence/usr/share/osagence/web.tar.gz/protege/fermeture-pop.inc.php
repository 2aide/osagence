<!-- ÿ caractere pour reconnaissance utf8 -->
<!-- Fermeture des Popup  -->
<p>
<script type="text/javascript">
if (window.opener) document.write('Cliquez dans la fen&ecirc;tre pour la fermer');
</script>
</p>
<script type="text/JavaScript">
document.write('<span style=\"display : none\"\>');
</script>
<h3>
<a href="<?php echo $_SERVER["HTTP_REFERER"];?>">Fermer cette fen&ecirc;tre, retour</a>
</h3>
<script type="text/JavaScript">
document.write('<\/span\>');
</script>
<!-- Fin fermeture des Popup -->
