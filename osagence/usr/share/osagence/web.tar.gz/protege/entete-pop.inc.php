<?php
header('Content-type: text/html; charset=utf-8');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html lang="fr">
<head>
<meta name="robots" content="noindex, nofollow">
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="generator" content="Geany">
<meta name="publisher" content="2aide">
<meta name="author" content="2aide" lang="fr">
<link rel="stylesheet" media="screen, projection" type="text/css" id="css" href="styles/default/style.css">
<!-- Fin entete commune des Popup  -->
<!-- ÿ caractere pour reconnaissance utf8 -->