			<!-- Menu haut de la page ÿ caractere pour reconnaissance utf8-->
		  <a class="menutop" href="index.php">Tout</a>
		  <a class="menutop" href="index.php?pr=1">0 &agrave; 50000&euro;</a>
		  <a class="menutop" href="index.php?pr=2">50 &agrave; 100000&euro;</a>
		  <a class="menutop" href="index.php?pr=3">100 &agrave; 250000&euro;</a>
		  <a class="menutop" href="index.php?pr=4">250 &agrave; 300000&euro;</a>
		  <a class="menutop" href="index.php?pr=5">+ de 300000&euro;</a>
		  <!-- Fin menu haut de la page ÿ caractere pour reconnaissance utf8-->
