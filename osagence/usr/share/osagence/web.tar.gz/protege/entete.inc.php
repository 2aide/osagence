<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html lang="fr">
<head>
	<meta http-equiv="Content-Language" content="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="Content-Style-Type" content="text/css">
	<meta name="generator" content="Geany">
	<meta name="publisher" content="2aide">
	<meta name="author" content="www.2aide.fr" lang="fr">
	<link rel="stylesheet" media="screen, projection" type="text/css" href="styles/default/style.css">
	<!-- Fin entete commune aux pages sans fonctions specifiques -->
	<!-- ÿ caractere pour reconnaissance utf8 -->